window.onload=function(){
    //横向轮播图
    $(function(){
        $('.sowingAll').liMarquee(
            {
                hoverstop:true
            }
        );
    });
    var $caseImg = $('#caseImg')
//  $caseImg.css("left","-375")
    moveU($caseImg)
    //左右滑动函数
    function moveU(obj) {
		obj.on('touchstart', function(ev) {
			lW = $(this).width() - screen.width*3;
			console.log(lW)
			//定义按下的x的点
			this.x = ev.originalEvent.targetTouches[0].pageX;
			this.ulLeft = $(this).offset().left;
		})
	
		obj.on('touchmove', function(ev) {
				//移动时的x点
				var x2 = ev.originalEvent.targetTouches[0].pageX;
				var l = x2 + this.ulLeft - this.x
	
				if(l <= -lW) {
					l = -lW
				} else if(l >= 0) {
					l = 0;
				}
				$(this).css('left', l + "px");
			});
		}

    //切割获取url里的id
    // var strUrl = "www/activity/123/SVGAnimatedTransformList";
    var strUrl = window.location.href;
    var str2 = strUrl.match("activity/\\d+/");
    if(str2){
        var activityId = parseInt(str2[0].split("/")[1])
    }
    $(".btn").click(function(){
        if($(".username").val().replace(/(^\s*)|(\s*$)/g, "")==""){
            $(".mustName").css("display","block")
            return;
        }
        if($(".tel").val().replace(/(^\s*)|(\s*$)/g, "")==""){
            $(".mustTle").css("display","block")
            return;
        }else if(!(/^1[34578]\d{9}$/.test($(".tel").val()))){
            $(".mustTle2").css("display","block")
            return;
        }
        if($(".city").val().replace(/(^\s*)|(\s*$)/g, "")==""){
            $(".mustCity").css("display","block")
            return;
        }
        if($(".content").val().replace(/(^\s*)|(\s*$)/g, "")==""){
            $(".mustContent").css("display","block")
            return;
        }
        var content =  {
            "name":$(".username").val(),
            "tel":$(".tel").val(),
            "city":$(".city").val(),
            "content":$(".content").val()
        }
        if(typeof content === "object"){
            content = JSON.stringify(content)
        }
        var datas = {};
        datas.activityId = activityId;
        datas.content = content;
        if(typeof datas === "object"){
            data = JSON.stringify(datas)
        }
        $.ajax({
            type: "post",
            url: "/services/activity/reply",
            data:data,
            contentType: "application/json",
            success: function(data){
                $(".mustmust").css("display","none")
                    // location.href="enlist.html"
                    $(".ipt").css("display","none")
                    $(".baoming").css("display","none")
                    $(".enlist").css("display","block")
                  },
            error:function(){
                alert("服务器错误，请稍后再试！")
            }
                })
        })
    }



















